#
# TABLE STRUCTURE FOR: codes
#

DROP TABLE IF EXISTS `codes`;

CREATE TABLE `codes` (
  `code_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) DEFAULT NULL,
  `generated_date` varchar(100) DEFAULT NULL,
  `generated_by` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `used_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: commission
#

DROP TABLE IF EXISTS `commission`;

CREATE TABLE `commission` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_user_id` int(11) DEFAULT NULL,
  `c_amount` float DEFAULT NULL,
  `r_user_id` int(11) DEFAULT NULL,
  `depth` varchar(11) DEFAULT NULL,
  `remarks` varchar(45) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  PRIMARY KEY (`commission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('1', '2', '50', '3', NULL, 'referral', '2017-02-26 10:18:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('2', '2', '50', '4', NULL, 'referral', '2017-02-26 10:18:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('3', '2', '50', '5', NULL, 'referral', '2017-02-26 10:18:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('4', '2', '50', '6', NULL, 'referral', '2017-02-26 10:18:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('5', '2', '50', '7', NULL, 'referral', '2017-02-26 10:18:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('6', '2', '50', '8', NULL, 'referral', '2017-02-26 10:18:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('7', '2', '50', '9', NULL, 'referral', '2017-02-26 10:18:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('8', '2', '50', '10', NULL, 'referral', '2017-02-26 10:18:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('9', '2', '50', '11', NULL, 'referral', '2017-02-26 10:18:24');


#
# TABLE STRUCTURE FOR: hierarchy
#

DROP TABLE IF EXISTS `hierarchy`;

CREATE TABLE `hierarchy` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT NULL,
  `child` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `m_position` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('1', '2', '2', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('2', '2', '2', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('3', '3', '3', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('4', '4', '4', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('5', '5', '5', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('6', '6', '6', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('7', '7', '7', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('8', '8', '8', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('9', '9', '9', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('10', '10', '10', '0', 'parent', NULL, 'SystemCreate', '2017-02-26 10:18:24');


#
# TABLE STRUCTURE FOR: position
#

DROP TABLE IF EXISTS `position`;

CREATE TABLE `position` (
  `position_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) DEFAULT NULL,
  `position_left` varchar(100) DEFAULT NULL,
  `position_right` varchar(100) NOT NULL,
  `sponsor_by` varchar(100) DEFAULT NULL,
  `upline` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('1', '2', '', '', '2', '2');
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('2', '3', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('3', '4', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('4', '5', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('5', '6', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('6', '7', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('7', '8', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('8', '9', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('9', '10', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('10', '11', '', '', '2', NULL);


#
# TABLE STRUCTURE FOR: product_purchase
#

DROP TABLE IF EXISTS `product_purchase`;

CREATE TABLE `product_purchase` (
  `product_purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` varchar(100) NOT NULL,
  `date_purchase` date NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`product_purchase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: request_withdrawal
#

DROP TABLE IF EXISTS `request_withdrawal`;

CREATE TABLE `request_withdrawal` (
  `request_withdrawal_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` varchar(100) NOT NULL,
  `date_requested` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`request_withdrawal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `entered_on` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `sponsor_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('1', 'admin', '12345', 'Luyabaya', 'Admin', '', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '', '1', 'luyabaya@gmail.com', '');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('2', 'luyabaya1', '12345', 'Luyabaya', '1', '', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('3', 'luyabaya2', '12345', 'Luyabaya', '2', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya2@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('4', 'luyabaya3', '12345', 'Luyabaya', '3', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya3@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('5', 'luyabaya4', '12345', 'Luyabaya', '4', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya4@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('6', 'luyabaya5', '12345', 'Luyabaya', '5', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya5@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('7', 'luyabaya6', '12345', 'Luyabaya', '6', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya6@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('8', 'luyabaya7', '12345', 'Luyabaya', '7', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya7@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('9', 'luyabaya8', '12345', 'Luyabaya', '8', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya8@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('10', 'luyabaya9', '12345', 'Luyabaya', '9', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya9@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('11', 'luyabaya10', '12345', 'Luyabaya', '10', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-02-26 10:18:24', '1', '0', 'luyabaya10@gmail.com', '2');


#
# TABLE STRUCTURE FOR: withdrawal
#

DROP TABLE IF EXISTS `withdrawal`;

CREATE TABLE `withdrawal` (
  `withdrawal_id` int(11) NOT NULL AUTO_INCREMENT,
  `w_user_id` int(11) DEFAULT NULL,
  `w_amount` float DEFAULT NULL,
  `remarks` varchar(45) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  PRIMARY KEY (`withdrawal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

