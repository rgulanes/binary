#
# TABLE STRUCTURE FOR: _currentchild
#

DROP TABLE IF EXISTS `_currentchild`;

CREATE TABLE `_currentchild` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `old_count` int(11) DEFAULT '0',
  `new_count` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `_currentchild` (`id`, `parent`, `old_count`, `new_count`) VALUES ('1', '2', '6', '6');
INSERT INTO `_currentchild` (`id`, `parent`, `old_count`, `new_count`) VALUES ('2', '3', '2', '0');
INSERT INTO `_currentchild` (`id`, `parent`, `old_count`, `new_count`) VALUES ('3', '4', '2', '2');
INSERT INTO `_currentchild` (`id`, `parent`, `old_count`, `new_count`) VALUES ('4', '5', '0', '0');
INSERT INTO `_currentchild` (`id`, `parent`, `old_count`, `new_count`) VALUES ('5', '6', '0', '0');
INSERT INTO `_currentchild` (`id`, `parent`, `old_count`, `new_count`) VALUES ('6', '7', '0', '0');
INSERT INTO `_currentchild` (`id`, `parent`, `old_count`, `new_count`) VALUES ('7', '8', '0', '0');


#
# TABLE STRUCTURE FOR: _selectedhierarchy
#

DROP TABLE IF EXISTS `_selectedhierarchy`;

CREATE TABLE `_selectedhierarchy` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `child` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  `full_name` varchar(150) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `m_position` varchar(50) DEFAULT NULL,
  `m_parent` int(10) DEFAULT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `_selectedhierarchy` (`_id`, `child`, `depth`, `full_name`, `parent`, `position`, `m_position`, `m_parent`) VALUES ('1', '3', '0', 'Luyabaya 2', '2', 'parent', NULL, '3');
INSERT INTO `_selectedhierarchy` (`_id`, `child`, `depth`, `full_name`, `parent`, `position`, `m_position`, `m_parent`) VALUES ('2', '3', '0', 'Luyabaya 2', '2', 'left', 'left', '3');
INSERT INTO `_selectedhierarchy` (`_id`, `child`, `depth`, `full_name`, `parent`, `position`, `m_position`, `m_parent`) VALUES ('3', '5', '1', 'Luyabaya 4', '3', 'left', 'left', '3');
INSERT INTO `_selectedhierarchy` (`_id`, `child`, `depth`, `full_name`, `parent`, `position`, `m_position`, `m_parent`) VALUES ('4', '6', '1', 'Luyabaya 5', '3', 'right', 'left', '3');


#
# TABLE STRUCTURE FOR: codes
#

DROP TABLE IF EXISTS `codes`;

CREATE TABLE `codes` (
  `code_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) DEFAULT NULL,
  `generated_date` varchar(100) DEFAULT NULL,
  `generated_by` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `used_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: commission
#

DROP TABLE IF EXISTS `commission`;

CREATE TABLE `commission` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_user_id` int(11) DEFAULT NULL,
  `c_amount` float DEFAULT NULL,
  `r_user_id` int(11) DEFAULT NULL,
  `depth` varchar(11) DEFAULT NULL,
  `remarks` varchar(45) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  PRIMARY KEY (`commission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('1', '2', '50', '3', NULL, 'referral', '2017-03-06 20:02:10');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('2', '2', '50', '4', NULL, 'referral', '2017-03-06 20:02:10');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('3', '2', '50', '5', NULL, 'referral', '2017-03-06 20:02:10');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('4', '2', '50', '6', NULL, 'referral', '2017-03-06 20:02:10');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('5', '2', '50', '7', NULL, 'referral', '2017-03-06 20:02:10');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('6', '2', '50', '8', NULL, 'referral', '2017-03-06 20:02:10');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('7', '2', '60', '2', 'pairing_1', 'upline', '2017-03-06 20:02:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('8', '2', '60', '2', 'pairing_2', 'upline', '2017-03-06 20:02:24');
INSERT INTO `commission` (`commission_id`, `c_user_id`, `c_amount`, `r_user_id`, `depth`, `remarks`, `date_create`) VALUES ('9', '2', '60', '2', 'pairing_3', 'upline', '2017-03-06 20:02:24');


#
# TABLE STRUCTURE FOR: hierarchy
#

DROP TABLE IF EXISTS `hierarchy`;

CREATE TABLE `hierarchy` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT NULL,
  `child` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  `position` varchar(45) DEFAULT NULL,
  `m_position` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('1', '2', '2', '0', 'parent', NULL, 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('2', '2', '2', '0', 'parent', NULL, 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('3', '3', '3', '0', 'parent', NULL, 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('4', '4', '4', '0', 'parent', NULL, 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('5', '5', '5', '0', 'parent', NULL, 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('6', '6', '6', '0', 'parent', NULL, 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('7', '7', '7', '0', 'parent', NULL, 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('8', '2', '3', '1', 'left', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('9', '2', '3', '1', 'left', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('10', '3', '3', '0', 'left', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('11', '2', '4', '1', 'right', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('12', '2', '4', '1', 'right', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('13', '4', '4', '0', 'right', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('14', '3', '5', '1', 'left', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('15', '2', '5', '2', 'left', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('16', '2', '5', '2', 'left', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('17', '3', '5', '1', 'left', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('18', '5', '5', '0', 'left', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('21', '3', '6', '1', 'right', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('22', '2', '6', '2', 'right', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('23', '2', '6', '2', 'right', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('24', '3', '6', '1', 'right', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('25', '6', '6', '0', 'right', 'left', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('28', '4', '7', '1', 'left', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('29', '2', '7', '2', 'left', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('30', '2', '7', '2', 'left', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('31', '4', '7', '1', 'left', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('32', '7', '7', '0', 'left', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('35', '4', '8', '1', 'right', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('36', '2', '8', '2', 'right', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('37', '2', '8', '2', 'right', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('38', '4', '8', '1', 'right', 'right', 'SystemCreate', '2017-03-06 20:02:10');
INSERT INTO `hierarchy` (`p_id`, `parent`, `child`, `depth`, `position`, `m_position`, `created_by`, `datetime`) VALUES ('39', '8', '8', '0', 'right', 'right', 'SystemCreate', '2017-03-06 20:02:10');


#
# TABLE STRUCTURE FOR: position
#

DROP TABLE IF EXISTS `position`;

CREATE TABLE `position` (
  `position_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) DEFAULT NULL,
  `position_left` varchar(100) DEFAULT NULL,
  `position_right` varchar(100) NOT NULL,
  `sponsor_by` varchar(100) DEFAULT NULL,
  `upline` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('1', '2', '3', '4', '2', '2');
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('2', '3', '5', '6', '2', '3');
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('3', '4', '7', '8', '2', '4');
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('4', '5', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('5', '6', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('6', '7', '', '', '2', NULL);
INSERT INTO `position` (`position_id`, `user_id`, `position_left`, `position_right`, `sponsor_by`, `upline`) VALUES ('7', '8', '', '', '2', NULL);


#
# TABLE STRUCTURE FOR: product_purchase
#

DROP TABLE IF EXISTS `product_purchase`;

CREATE TABLE `product_purchase` (
  `product_purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` varchar(100) NOT NULL,
  `date_purchase` date NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`product_purchase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: request_withdrawal
#

DROP TABLE IF EXISTS `request_withdrawal`;

CREATE TABLE `request_withdrawal` (
  `request_withdrawal_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` varchar(100) NOT NULL,
  `date_requested` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`request_withdrawal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `entered_on` datetime DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `sponsor_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('1', 'admin', '12345', 'Luyabaya', 'Admin', '', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-03-06 20:02:10', '', '1', 'luyabaya@gmail.com', '');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('2', 'luyabaya1', '12345', 'Luyabaya', '1', '', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-03-06 20:02:10', '1', '0', 'luyabaya@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('3', 'luyabaya2', '12345', 'Luyabaya', '2', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-03-06 20:02:10', '1', '0', 'luyabaya2@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('4', 'luyabaya3', '12345', 'Luyabaya', '3', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-03-06 20:02:10', '1', '0', 'luyabaya3@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('5', 'luyabaya4', '12345', 'Luyabaya', '4', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-03-06 20:02:10', '1', '0', 'luyabaya4@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('6', 'luyabaya5', '12345', 'Luyabaya', '5', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-03-06 20:02:10', '1', '0', 'luyabaya5@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('7', 'luyabaya6', '12345', 'Luyabaya', '6', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-03-06 20:02:10', '1', '0', 'luyabaya6@gmail.com', '2');
INSERT INTO `users` (`user_id`, `user_name`, `password`, `first_name`, `last_name`, `gender`, `contact`, `address`, `entered_on`, `status`, `position`, `email`, `sponsor_by`) VALUES ('8', 'luyabaya7', '12345', 'Luyabaya', '7', 'M', '(082) 282 8849', 'Jacinto Extension (Infront of Blueberry Hotel), Davao City, Philippines', '2017-03-06 20:02:10', '1', '0', 'luyabaya7@gmail.com', '2');


#
# TABLE STRUCTURE FOR: withdrawal
#

DROP TABLE IF EXISTS `withdrawal`;

CREATE TABLE `withdrawal` (
  `withdrawal_id` int(11) NOT NULL AUTO_INCREMENT,
  `w_user_id` int(11) DEFAULT NULL,
  `w_amount` float DEFAULT NULL,
  `remarks` varchar(45) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  PRIMARY KEY (`withdrawal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

